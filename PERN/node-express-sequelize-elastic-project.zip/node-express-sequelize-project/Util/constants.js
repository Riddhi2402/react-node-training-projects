module.exports = Text = {
  serverStartMessage: 'Server started on port',
  databaseMessage: 'Database connected',
  updateMessage: 'updated successfully',
  deleteMessage: 'deleted successfully',
};
